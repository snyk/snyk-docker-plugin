Just a regular file, not a container image.
